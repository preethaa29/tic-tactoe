# Game Instructions

- press 'g' to change gamemode (pvp or ai)
- press '0' to change ai level to 0 (random)
- press '1' to change ai level to 1 (impossible)
- press 'r' to restart the game

# Game Snapshots

## Snapshot 1 - Start
![snapshot1](snapshots/snapshot1.png)

## Snapshot 2 - Circle Win
![snapshot2](snapshots/snapshot2.png)

## Snapshot 3 - Cross Win
![snapshot3](snapshots/snapshot3.png)
